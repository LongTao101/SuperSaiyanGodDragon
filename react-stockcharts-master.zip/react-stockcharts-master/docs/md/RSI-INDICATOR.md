The chart below has an RSI and ATR indicator

Learn more about constructing a RSI [here](http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi)

Learn more about constructing a ATR [here](http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:average_true_range_atr)

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithRSIIndicator.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithRSIIndicator)
