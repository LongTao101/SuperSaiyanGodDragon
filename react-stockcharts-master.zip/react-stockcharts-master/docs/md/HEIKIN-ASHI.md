
Also known as "average bar", used to identify trends and filter out noise. Learn more about how to construct one [here](http://stockcharts.com/school/doku.php?id=chart_school:chart_analysis:heikin_ashi) and [here](http://www.investopedia.com/articles/technical/04/092204.asp)

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/HeikinAshi.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/HeikinAshi)
