https://www.metatrader5.com/en/terminal/help/objects/gann/gann_fan

- create a fan - click, mousemove, click
- Once a fan is drawn it gets out of draw mode automatically. To get back into draw mode again - Press D
- Get out of draw mode - Press ESC
- Delete the last drawn fan - Press DEL
- When not in draw mode
	- move mouse over to hover state
	- click to select
	- move the edge circles
	- Click outside to unselect

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithGannFan.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithGannFan)
