Advanced chart type plots price action. Notice that the x axis is not linear.

Learn more about it [here](http://stockcharts.com/school/doku.php?id=chart_school:chart_analysis:kagi)

Kagi consists of *Yin* and *Yang*, which is represented as red and green respectively. An overly simple rule is buy on Yang and sell on Yin.

ATR(14) is used as the default reversal amount.

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/Kagi.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/Kagi)
