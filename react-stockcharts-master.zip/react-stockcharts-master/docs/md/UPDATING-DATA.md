This example illustrates how to push new data points or alter existing data points to a chart after initial render.

When just update the `data={...}` on the `ChartCanvas` and see the new points


A live example below, Here are a keys to press to see the push and alter data2

key   | outcome
----  | -------
1     | push new data points
0/Esc | stop all push/alter
+     | increase the speed
-     | reduce the speed

Look for the [source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithUpdatingData.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithUpdatingData)
