Force Index Indicator

Learn more about how to [plot](http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:force_index) it

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithForceIndexIndicator.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithForceIndexIndicator)
