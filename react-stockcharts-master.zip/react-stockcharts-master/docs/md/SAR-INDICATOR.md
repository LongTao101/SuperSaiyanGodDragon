Learn more about how to [plot](http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:parabolic_sar) it

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithSAR.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithSAR)
