Learn more about constructing a Stochastic Oscillator [here](http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:stochastic_oscillator_fast_slow_and_full)

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithFullStochasticsIndicator.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithFullStochasticsIndicator)



this example also introduces a grid, look for `var showGrid = true;` in the example source. 