An example with `SingleValueTooltip` & `widthRatio` prop on `BarSeries`

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/AreaChartWithZoomPan.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/AreaChartWithZoomPan)