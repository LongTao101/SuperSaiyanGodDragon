Inspired by [d3fc](https://github.com/ScottLogic/d3fc) [example](https://d3fc.io/examples/bubble/index.html)

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/BubbleChart.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/BubbleChart)
