- create a channel - click, mousemove, click, mousemove, click
- Once a channel is drawn it gets out of draw mode automatically. To get back into draw mode again - Press D
- Get out of draw mode - Press ESC
- Delete the last drawn channel - Press DEL
- When not in draw mode
	- move mouse over to hover state
	- click to select
	- move the edge circles and the top/bottom lines
	- Click outside to unselect

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithEquidistantChannel.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithEquidistantChannel)
