Similar to Point and Figure charts in that Renko plots the price movement ignoring the time. Each brick is formed on a different column when the price moves beyond a threshold.

Brick size defaults to ATR (14)

Learn more about it [here](http://stockcharts.com/school/doku.php?id=chart_school:chart_analysis:renko)

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/Renko.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/Renko)
