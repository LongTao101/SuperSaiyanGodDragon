Elder Ray Indicator

Learn more about how to [plot](http://stockmarketstudent.com/elder-ray-index/) it

This chart is also an example of OHLC chart

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/OHLCChartWithElderRayIndicator.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/OHLCChartWithElderRayIndicator) of this example
