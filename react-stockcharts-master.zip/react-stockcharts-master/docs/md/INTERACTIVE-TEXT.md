- create a fan - click
- Edit the text and save. To get back into draw mode again - Press D
- Get out of draw mode - Press ESC
- Delete the last text - Press DEL
- When not in draw mode
	- move mouse over to hover state
	- click to select
	- drag

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithText.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithText)
