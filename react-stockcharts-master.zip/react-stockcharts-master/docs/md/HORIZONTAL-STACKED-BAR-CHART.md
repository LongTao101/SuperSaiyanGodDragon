Notice the `flipScales` on the `StackedBarSeries`

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/HorizontalStackedBarChart.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/HorizontalStackedBarChart)