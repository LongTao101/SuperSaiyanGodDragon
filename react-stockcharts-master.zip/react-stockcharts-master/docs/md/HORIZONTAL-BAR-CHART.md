Notice the `flipScales` on the `BarSeries`

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/HorizontalBarChart.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/HorizontalBarChart)