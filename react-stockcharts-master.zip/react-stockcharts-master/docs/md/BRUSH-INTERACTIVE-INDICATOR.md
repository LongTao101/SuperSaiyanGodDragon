- click to start, move to the end and click again
- Types of Brush
	- 1D (default)
	- 2D

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithBrush.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithBrush)
 of this example, search for `handleBrush` to see how to make the chart zoom in on brush complete
