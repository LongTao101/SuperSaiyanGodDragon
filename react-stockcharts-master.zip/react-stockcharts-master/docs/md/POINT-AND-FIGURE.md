Advanced chart type plots price action. Notice that the x axis is not linear.

Learn more about it [here](http://stockcharts.com/docs/doku.php?id=other-tools:pnf-charts)

default is 3 box reversal.

[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/PointAndFigure.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/PointAndFigure)
