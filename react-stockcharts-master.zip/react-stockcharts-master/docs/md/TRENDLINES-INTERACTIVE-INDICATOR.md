- create a line - click, mousemove, click
	- by default the line edge snaps to the nearest high or low, press Shift when you click to disable snap temporarily
- Once a line is drawn it gets out of draw mode automatically. To get back into draw mode again - Press D
- Delete the last drawn line - Press DEL
- Get out of draw mode - Press ESC
- When not in draw mode
	- hover and click to select
	- move the line or edges
	- click outside to unselect


[source](https://github.com/rrag/react-stockcharts/blob/master/docs/lib/charts/CandleStickChartWithInteractiveIndicator.js), [codesandbox](https://codesandbox.io/s/github/rrag/react-stockcharts-examples2/tree/master/examples/CandleStickChartWithInteractiveIndicator)

